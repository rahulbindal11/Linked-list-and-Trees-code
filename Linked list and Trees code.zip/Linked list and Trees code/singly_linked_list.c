#include<stdio.h>
#include<stdlib.h>

struct node
{
	int info;
	int Field;
	struct node *link;
	struct node *ptr;
	
};
void display (struct node * );
void count (struct node * );
struct node * insert_begin (int,struct node * );
struct node * insert_last(int,struct node * );
struct node * insert_betweeninORDL(int,struct node * );
struct node * Delete (struct node *,struct node * );
struct node * copyele(struct node * );
void main()
{
struct node *first,*second,*third,*fourth;
first = (struct node *)malloc(sizeof(struct node));
second = (struct node *)malloc(sizeof(struct node));
third = (struct node *)malloc(sizeof(struct node));
fourth = (struct node *)malloc(sizeof(struct node));
first->info = 5;
first->link = second;
second->info = 7;
second->link = third;
third->info = 10;
third->link =NULL;
first=insert_begin(4,first);
first=insert_last(32,first);
first=insert_betweeninORDL(3,first);
first=insert_betweeninORDL(4,first);
display(first);
fourth=copyele(first);
printf("\nList copied from original list is :\n");
display(first);
first=Delete(first,first);
printf("\nList after deleting element is:\n");
display(first);
count(first);
}
void display (struct node *first)
{
	struct node *save;
	save = first;
	while(save!=NULL)
	{
		printf("%d,",save->info);
		save = save->link;
	}
}
void count (struct node *first)
{
	int count =0;
	struct node *save;
	save = first;
	while(save!=NULL)
	{
		count++;
		save = save->link;
	}
	printf("\nNumber of nodes in linked list are %d",count);

}
struct node * insert_begin(int x,struct node *first)
{
	struct node *new;
	new = (struct node *)malloc(sizeof(struct node));
	if(new==NULL)
	{
		printf("overflow");
		return first;
	}
	else
	{	new->info = x;
		new->link = first;
		return new;
	}
	
}
struct node * insert_last(int x,struct node *first)
{
	struct node *new;
	new = (struct node *)malloc(sizeof(struct node));
	if(new==NULL)
	{
		printf("underflow");
		return first;
	}
	
	else 
	{	
		new->info = x;
		new->link = NULL;
	}
	if(first==NULL)
	{
	return new;
	}
	struct node *save;
	save = first;
	while(save->link!=NULL)
	{
		save = save->link;
	}	
	save->link = new;
	return first;
}
struct node * insert_betweeninORDL(int x,struct node *first)
{
	struct node *new;
	new = (struct node *)malloc(sizeof(struct node));
	if(new==NULL)
	{
		printf("underflow");
		return first;
	}
	else 
	{
		new->info = x;
		if(first==NULL)
		{
		new->link = NULL;
		return new;
		}
		else if(new->info <= first->info)
		{
		new->link = first;
		return new;
		}
		
		else
		{
			struct node *save;
			save = first;
			while(save->link!=NULL && new->info >= save->link->info)
			{
				save = save->link;
			}	
			new->link = save->link;
			save->link = new;
			return first;
		}
	}
}
struct node * Delete(struct node *x,struct node *first)
{
	if(first==NULL)
	{
		printf("underflow");
		return 0;
	}
	struct node *pred;
	pred =(struct node*)malloc(sizeof(struct node));
	struct node *save;
	save = first;
	while(save->link!=NULL && save!=x)
			{
				pred=save;
				save = save->link;
			}
	if(save!=x)
	{
	printf("node not found");
	return 0;
	}
		
	if(x==first)
	first=first->link;

	else
	pred->link = x->link;
	return first;
	free(x);	
	
}
struct node * copyele(struct node *first)
{
	if(first==NULL)
	{
	printf("empty");
	return NULL;
	}
	struct node *new;
	new = (struct node *)malloc(sizeof(struct node));
	struct node *save,*pred,*begin;
	if(new==NULL)
	{
		printf("underflow");
		return NULL;
	}
	else 
	{
		new->Field=first->info;
		begin = new;
	}
	save = first;
	while(save->link!=NULL)
			{
				pred=new;
				save = save->link;
				struct node *new;
			new = (struct node *)malloc(sizeof(struct node));
			if(new==NULL)
			{
				printf("underflow");
				return NULL;
			}
			else 
			{
				new->Field=save->info;
				pred->ptr=new;
			}
			}
			new->ptr=NULL;
			return begin;	
		
}